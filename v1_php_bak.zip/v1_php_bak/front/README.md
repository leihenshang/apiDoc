# apidoc
this is a front.use Vue.
## install package
yarn  or yarn install

## run 
yarn serve 

## build 
yarn build

## package image
yarn config set sass_binary_site http://cdn.npm.taobao.org/dist/node-sass -g
yarn config set registry https://registry.npm.taobao.org -g
### look config
yarn config get registry